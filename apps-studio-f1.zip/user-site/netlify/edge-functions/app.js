export default async (request, context) => {
    const url = new URL(request.url);
    const appId = url.searchParams.get("id");

    // No ID → serve normal app.html
    if (!appId) return context.next();

    // Firebase REST API থেকে app data নেওয়া
    let appData = null;
    try {
        const res = await fetch(
            `https://apps-studio-1f1c0-default-rtdb.firebaseio.com/apps/${appId}.json`
        );
        appData = await res.json();
    } catch (e) {
        return context.next();
    }

    if (!appData) return context.next();

    // App name ও category বের করা
    const codeCats = {
        S:'Social', G:'Games', E:'Entertainment',
        T:'Tools', D:'Education', P:'Productivity'
    };
    const name = appData.name || '';
    const lastChar = name.charAt(name.length - 1).toUpperCase();
    const displayName = codeCats[lastChar] ? name.slice(0, -1).trim() : name;
    const category = codeCats[lastChar] || 'App';
    const logo = appData.logo || '';
    const desc = appData.description ||
        `Download ${displayName} free on Apps Studio. ${category} app available for free.`;
    const shortDesc = desc.substring(0, 160);

    // Original app.html নেওয়া
    const response = await context.next();
    const originalHtml = await response.text();

    // Meta tags তৈরি
    const metaTags = `<title>${displayName} - Apps Studio</title>
    <meta name="description" content="${shortDesc}">
    <meta property="og:title" content="${displayName} - Apps Studio">
    <meta property="og:description" content="${shortDesc}">
    <meta property="og:image" content="${logo}">
    <meta property="og:url" content="${request.url}">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="${displayName} - Apps Studio">
    <meta name="twitter:description" content="${shortDesc}">
    <meta name="twitter:image" content="${logo}">`;

    // app.html-এর <title> replace করে meta tags বসানো
    const newHtml = originalHtml.replace(
        /<title>.*?<\/title>/,
        metaTags
    );

    return new Response(newHtml, {
        headers: { "content-type": "text/html;charset=UTF-8" },
    });
};
