// ========== FIREBASE CONFIG (Shared across all pages) ==========
const firebaseConfig = {
    apiKey: "AIzaSyByoVGSmDnWVYAY3CFFpHYOC2siWAH0ajE",
    authDomain: "apps-studio-1f1c0.firebaseapp.com",
    databaseURL: "https://apps-studio-1f1c0-default-rtdb.firebaseio.com",
    projectId: "apps-studio-1f1c0",
    storageBucket: "apps-studio-1f1c0.firebasestorage.app",
    messagingSenderId: "106546673585",
    appId: "1:106546673585:web:48f13f073d92d9cb58af90"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ========== CACHE SYSTEM (sessionStorage) ==========
// sessionStorage: tab চালু থাকলে data থাকে, বন্ধ হলে মুছে যায়

function cacheSet(key, data) {
    try {
        sessionStorage.setItem(key, JSON.stringify({ d: data, t: Date.now() }));
    } catch(e) {}
}

function cacheGet(key) {
    try {
        const raw = sessionStorage.getItem(key);
        if (!raw) return null;
        return JSON.parse(raw).d;
    } catch(e) { return null; }
}

function cacheClear(key) {
    try { sessionStorage.removeItem(key); } catch(e) {}
}

// ========== CATEGORY CODE MAPPING ==========
const categoryCodes = {
    'S': 'social',
    'G': 'games',
    'E': 'entertainment',
    'T': 'tools',
    'D': 'education',
    'P': 'productivity'
};

function processAppName(app) {
    const processed = { ...app };
    const name = processed.name || '';
    if (name.length > 1) {
        const lastChar = name.charAt(name.length - 1).toUpperCase();
        if (categoryCodes[lastChar]) {
            processed.category = categoryCodes[lastChar];
            processed.displayName = name.slice(0, -1).trim();
        } else {
            processed.displayName = name;
        }
    } else {
        processed.displayName = name;
    }
    return processed;
}

// ========== SHARED UTILITIES ==========
function getErrorImg(name) {
    return `data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%231a73e8%22 width=%22100%22 height=%22100%22 rx=%2220%22/><text x=%2250%22 y=%2255%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2240%22>${encodeURIComponent((name||'A').charAt(0))}</text></svg>`;
}

function showToast(msg) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

function showComingSoon() {
    document.getElementById('comingSoonModal').classList.add('active');
}
function closeComingSoon() {
    document.getElementById('comingSoonModal').classList.remove('active');
}

// ========== SCROLL: HEADER HIDE/SHOW ==========
window.addEventListener('scroll', () => {
    const header = document.getElementById('mainHeader');
    if (!header) return;
    const currentY = window.scrollY;
    if (currentY > (window._lastScrollY || 0) && currentY > 60) {
        header.classList.add('hide');
    } else {
        header.classList.remove('hide');
    }
    window._lastScrollY = currentY;
});

// ========== SHARED HEADER HTML ==========
function renderHeader() {
    return `
    <div class="header" id="mainHeader">
        <div class="logo-area">
            <div style="width:36px;height:36px;background:white;border-radius:8px;display:flex;align-items:center;justify-content:center;">
                <i class="fas fa-play" style="color:#1a73e8;font-size:18px;margin-left:2px;"></i>
            </div>
            <div>
                <h1>Apps Studio</h1>
                <span>apps-studio.xyz</span>
            </div>
            <div style="margin-left:auto;display:flex;gap:12px;align-items:center;">
                <a href="search.html" style="background:none;border:none;color:white;font-size:20px;cursor:pointer;">
                    <i class="fas fa-search"></i>
                </a>
                <a href="request.html" style="background:none;border:none;color:white;font-size:20px;cursor:pointer;">
                    <i class="fas fa-paper-plane"></i>
                </a>
                <button onclick="showComingSoon()" style="background:none;border:none;color:white;font-size:20px;cursor:pointer;">
                    <i class="fas fa-user-circle"></i>
                </button>
            </div>
        </div>
    </div>`;
}

// ========== SHARED BOTTOM NAV HTML ==========
// activePage: 'home' | 'toplist' | 'request' | 'profile'
function renderBottomNav(activePage) {
    const pages = [
        { key: 'home',    href: 'index.html',   icon: 'fa-home',        label: 'Home'     },
        { key: 'toplist', href: 'toplist.html',  icon: 'fa-fire',        label: 'Top List' },
        { key: 'request', href: 'request.html',  icon: 'fa-paper-plane', label: 'Request'  },
        { key: 'profile', href: '#',             icon: 'fa-user',        label: 'Profile'  },
    ];
    let html = '<div class="bottom-nav">';
    pages.forEach(p => {
        const isActive = p.key === activePage ? 'active' : '';
        const onclick = p.key === 'profile' ? 'onclick="showComingSoon();return false;"' : '';
        html += `
        <a href="${p.href}" class="nav-item ${isActive}" ${onclick}>
            <i class="fas ${p.icon}"></i>
            <span>${p.label}</span>
        </a>`;
    });
    html += '</div>';
    return html;
}

// ========== SHARED MODALS HTML ==========
function renderSharedModals() {
    return `
    <!-- Coming Soon Modal -->
    <div class="coming-soon-modal" id="comingSoonModal">
        <div class="coming-soon-box">
            <i class="fas fa-rocket"></i>
            <h2>Coming Soon!</h2>
            <p>Login / Sign Up feature is under development. Stay tuned!</p>
            <button onclick="closeComingSoon()">Got it!</button>
        </div>
    </div>
    <!-- Ad Overlay -->
    <div class="ad-overlay" id="adOverlay">
        <button class="ad-close-btn" onclick="closeAd ? closeAd() : null">✕</button>
        <iframe id="adFrame" src=""></iframe>
    </div>
    <!-- Toast -->
    <div class="toast" id="toast"></div>
    <!-- Bottom Ad Banner -->
    <div class="bottom-bar" id="bottomAdBar">
        <div id="bannerAdContainer">
            <script>
                atOptions = { 'key':'71971cef439f7e47d3f26f03c0ce1844','format':'iframe','height':50,'width':320,'params':{} };
            <\/script>
            <script src="https://www.highperformanceformat.com/71971cef439f7e47d3f26f03c0ce1844/invoke.js"><\/script>
        </div>
    </div>`;
}
