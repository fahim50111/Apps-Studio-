const CACHE = 'apps-studio-v12';

// Static files — প্রথমবার cache হবে
const STATIC = [
    '/index.html','/search.html','/request.html',
    '/toplist.html','/app.html',
    '/style.css','/script.js','/firebase-config.js'
];

// ===== INSTALL =====
self.addEventListener('install', e => {
    e.waitUntil(
        caches.open(CACHE).then(c => c.addAll(STATIC))
    );
    self.skipWaiting();
});

// ===== ACTIVATE: পুরনো cache মুছো =====
self.addEventListener('activate', e => {
    e.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
        )
    );
    self.clients.claim();
});

// ===== FETCH =====
self.addEventListener('fetch', e => {
    const url = new URL(e.request.url);

    // ১. Firebase, Google Fonts, Font Awesome, Ad network → bypass (network only)
    if (
        url.hostname.includes('firebase') ||
        url.hostname.includes('firebaseio') ||
        url.hostname.includes('googleapis.com') ||
        url.hostname.includes('gstatic.com') ||
        url.hostname.includes('highperformanceformat') ||
        url.hostname.includes('effectivegatecpm')
    ) {
        return; // browser নিজেই handle করবে
    }

    // ২. Font Awesome CSS & fonts → Cache first (কখনো বদলায় না)
    if (url.hostname.includes('cdnjs.cloudflare.com')) {
        e.respondWith(
            caches.match(e.request).then(cached => cached ||
                fetch(e.request).then(res => {
                    caches.open(CACHE).then(c => c.put(e.request, res.clone()));
                    return res;
                })
            )
        );
        return;
    }

    // ৩. HTML pages → Network first, cache fallback
    if (e.request.destination === 'document') {
        e.respondWith(
            fetch(e.request)
                .then(res => {
                    caches.open(CACHE).then(c => c.put(e.request, res.clone()));
                    return res;
                })
                .catch(() => caches.match(e.request) || caches.match('/index.html'))
        );
        return;
    }

    // ৪. CSS, JS → Cache first (bandwidth বাঁচাবে)
    if (e.request.destination === 'style' || e.request.destination === 'script') {
        e.respondWith(
            caches.match(e.request).then(cached => cached ||
                fetch(e.request).then(res => {
                    caches.open(CACHE).then(c => c.put(e.request, res.clone()));
                    return res;
                })
            )
        );
        return;
    }

    // ৫. Images → Cache first, network fallback
    if (e.request.destination === 'image') {
        e.respondWith(
            caches.match(e.request).then(cached => cached ||
                fetch(e.request).catch(() => new Response('', {status: 404}))
            )
        );
        return;
    }

    // ৬. বাকি সব → network
    e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});
