// ========== সব Global Variable উপরে ==========
var allApps = [];
var allBanners = [];
var bannersRendered = false;
var currentBannerIndex = 0;
var bannerInterval = null;
var fbAppsRef = null;
var fbBannersRef = null;

// ========== SORT ==========
function sortByDate(apps) {
    return apps.slice().sort(function(a, b) {
        var ta = a.updatedAt || a.timestamp || a.id || '';
        var tb = b.updatedAt || b.timestamp || b.id || '';
        if (typeof ta === 'string' && typeof tb === 'string') return tb > ta ? 1 : -1;
        return (tb || 0) - (ta || 0);
    });
}

// ========== DATE HELPERS ==========
function getDateKey(app) {
    var ts = app.updatedAt || app.timestamp;
    if (ts) return new Date(ts).toISOString().slice(0, 10);
    if (app.id && app.id.length >= 8) {
        var ms = parseInt(app.id.substring(0, 8), 36);
        if (!isNaN(ms) && ms > 1000000000000) return new Date(ms).toISOString().slice(0, 10);
    }
    return null;
}
function formatDateHeader(dk) {
    if (!dk) return null;
    var date = new Date(dk + 'T00:00:00');
    var thisYear = new Date().getFullYear();
    if (date.getFullYear() === thisYear)
        return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ========== BANNER SLIDER ==========
function renderBanners() {
    var section = document.getElementById('bannerSection');
    if (!section) return;

    if (allBanners.length === 0) {
        section.innerHTML = '<div class="no-banner"><i class="fas fa-images"></i><p>Apps Studio</p><p style="font-size:11px;color:#aaa;">Download your favorite apps</p></div>';
        return;
    }

    if (bannerInterval) { clearInterval(bannerInterval); bannerInterval = null; }
    currentBannerIndex = 0;

    var html = '<div class="banner-slider" id="bannerSlider">';
    allBanners.forEach(function(b) {
        html += '<div class="banner-slide" onclick="window.open(\'' + (b.link||'#') + '\',\'_blank\')">';
        html += '<img src="' + b.image + '" alt="' + (b.title||'Banner') + '" loading="lazy" onerror="this.src=\'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 400 180%22><rect fill=%22%231a73e8%22 width=%22400%22 height=%22180%22/><text x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2224%22 dy=%22.3em%22>Apps Studio</text></svg>\'">';
        if (b.title) {
            html += '<div class="banner-overlay"><h3>' + b.title + '</h3>';
            if (b.desc) html += '<p>' + b.desc + '</p>';
            html += '</div>';
        }
        html += '</div>';
    });
    html += '</div>';

    if (allBanners.length > 1) {
        html += '<div class="banner-dots" id="bannerDots">';
        allBanners.forEach(function(_, i) {
            html += '<div class="banner-dot ' + (i===0?'active':'') + '" onclick="goToBanner(' + i + ')"></div>';
        });
        html += '</div>';
    }

    section.innerHTML = html;
    // Banner HTML sessionStorage-এ save
    cacheSet('bannerHTML', html);

    if (allBanners.length > 1) {
        setTimeout(function() {
            bannerInterval = setInterval(function() {
                currentBannerIndex = (currentBannerIndex + 1) % allBanners.length;
                slideBanner();
            }, 4000);
        }, 300);
    }

    var slider = document.getElementById('bannerSlider');
    if (slider) {
        var startX = 0;
        slider.addEventListener('touchstart', function(e) { startX = e.touches[0].clientX; }, {passive:true});
        slider.addEventListener('touchend', function(e) {
            var diff = startX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) {
                if (diff > 0 && currentBannerIndex < allBanners.length - 1) currentBannerIndex++;
                else if (diff < 0 && currentBannerIndex > 0) currentBannerIndex--;
                slideBanner();
                if (bannerInterval) clearInterval(bannerInterval);
                bannerInterval = setInterval(function() {
                    currentBannerIndex = (currentBannerIndex + 1) % allBanners.length;
                    slideBanner();
                }, 4000);
            }
        }, {passive:true});
    }
}

function slideBanner() {
    var slider = document.getElementById('bannerSlider');
    if (slider) slider.style.transform = 'translateX(-' + (currentBannerIndex * 100) + '%)';
    document.querySelectorAll('.banner-dot').forEach(function(d, i) {
        d.classList.toggle('active', i === currentBannerIndex);
    });
}

function goToBanner(i) {
    currentBannerIndex = i;
    slideBanner();
    if (bannerInterval) clearInterval(bannerInterval);
    bannerInterval = setInterval(function() {
        currentBannerIndex = (currentBannerIndex + 1) % allBanners.length;
        slideBanner();
    }, 4000);
}

// ========== HOME: Play Store Style ==========
function renderHome() {
    var main = document.getElementById('mainContent');
    if (!main) return;
    if (allApps.length === 0) {
        main.innerHTML = '<div class="no-results"><i class="fas fa-box-open" style="display:block;"></i><h3 style="margin-top:8px;">No Apps Available</h3><p>Check back later!</p></div>';
        return;
    }

    var sorted = sortByDate(allApps);
    var html = '';

    // New & Updated
    var newest = sorted.slice(0, 10);
    html += '<div class="ps-section"><div class="ps-section-header"><span class="ps-section-title">🆕 New & Updated</span><a href="#" onclick="showAllApps();return false;" class="ps-see-more">See more</a></div><div class="ps-scroll-row">';
    newest.forEach(function(app) {
        var dName = app.displayName || app.name;
        var cat = app.category ? app.category.charAt(0).toUpperCase()+app.category.slice(1) : 'App';
        html += '<div class="ps-app-card" onclick="location.href=\'app.html?id=' + app.id + '\'">';
        html += '<img src="' + app.logo + '" alt="' + dName + '" loading="lazy" onerror="this.src=\'' + getErrorImg(dName) + '\'">';
        html += '<div class="ps-app-name">' + dName + '</div>';
        html += '<div class="ps-app-cat">' + cat + '</div></div>';
    });
    html += '</div></div>';

    // Top Downloads
    var topDl = allApps.slice().sort(function(a,b){ return (b.downloads||0)-(a.downloads||0); }).slice(0,5);
    if (topDl.some(function(a){ return (a.downloads||0) > 0; })) {
        var rankColors = ['#f7c948','#b0bec5','#cd7f32','#888','#888'];
        html += '<div class="ps-section"><div class="ps-section-header"><span class="ps-section-title">🔥 Top Downloads</span><div style="display:flex;gap:8px;align-items:center;"><a href="news.html" style="background:#ff6b35;color:white;font-size:11px;font-weight:700;padding:4px 10px;border-radius:12px;text-decoration:none;display:flex;align-items:center;gap:4px;"><i class="fas fa-newspaper"></i> News</a><a href="toplist.html" class="ps-see-more">See more</a></div></div>';
        topDl.forEach(function(app, i) {
            var dName = app.displayName || app.name;
            var cat = app.category ? app.category.charAt(0).toUpperCase()+app.category.slice(1) : 'App';
            html += '<div class="ps-list-item" onclick="location.href=\'app.html?id=' + app.id + '\'">';
            html += '<div class="ps-rank" style="color:' + rankColors[i] + '">' + (i+1) + '</div>';
            html += '<img src="' + app.logo + '" alt="' + dName + '" loading="lazy" onerror="this.src=\'' + getErrorImg(dName) + '\'">';
            html += '<div class="ps-list-info"><div class="ps-list-name">' + dName + '</div>';
            html += '<div class="ps-list-sub">' + cat + ' • ' + (app.downloads||0) + ' downloads</div></div>';
            html += '<button class="ps-install-btn" onclick="event.stopPropagation();location.href=\'app.html?id=' + app.id + '\'">Install</button></div>';
        });
        html += '</div>';
    }

    // Category sections
    var cats = [];
    allApps.forEach(function(a) { if (a.category && cats.indexOf(a.category) === -1) cats.push(a.category); });
    cats.forEach(function(cat) {
        var catApps = sortByDate(allApps.filter(function(a){ return a.category === cat; })).slice(0, 8);
        if (!catApps.length) return;
        var catName = cat.charAt(0).toUpperCase() + cat.slice(1);
        var icons = {social:'👥',games:'🎮',tools:'🔧',entertainment:'🎬',education:'📚',productivity:'💼'};
        var icon = icons[cat] || '📱';
        html += '<div class="ps-section"><div class="ps-section-header"><span class="ps-section-title">' + icon + ' ' + catName + '</span>';
        html += '<a href="#" onclick="filterByCat(\'' + cat + '\');return false;" class="ps-see-more">See more</a></div>';
        html += '<div class="ps-scroll-row">';
        catApps.forEach(function(app) {
            var dName = app.displayName || app.name;
            html += '<div class="ps-app-card" onclick="location.href=\'app.html?id=' + app.id + '\'">';
            html += '<img src="' + app.logo + '" alt="' + dName + '" loading="lazy" onerror="this.src=\'' + getErrorImg(dName) + '\'">';
            html += '<div class="ps-app-name">' + dName + '</div>';
            html += '<div class="ps-app-cat">' + catName + '</div></div>';
        });
        html += '</div></div>';
    });

    // All Apps
    html += '<div class="ps-section" id="allAppsSection" style="display:none;">';
    html += '<div class="ps-section-header"><span class="ps-section-title">📋 All Apps</span><a href="#" onclick="hideAllApps();return false;" class="ps-see-more">Hide</a></div>';
    html += buildAllList(sorted);
    html += '</div>';

    main.innerHTML = html;

    // Rendered HTML sessionStorage-এ save করো
    cacheSet('homeHTML', html);
}

function buildAllList(apps) {
    var html = '', lastDk = null;
    apps.forEach(function(app) {
        var dName = app.displayName || app.name;
        var dk = getDateKey(app);
        if (dk !== lastDk) {
            var label = formatDateHeader(dk);
            if (label) html += '<div style="padding:14px 20px 4px;font-size:18px;font-weight:700;color:#222;">' + label + '</div>';
            lastDk = dk;
        }
        var cat = app.category ? app.category.charAt(0).toUpperCase()+app.category.slice(1) : 'App';
        html += '<div class="ps-list-item" onclick="location.href=\'app.html?id=' + app.id + '\'">';
        html += '<img src="' + app.logo + '" alt="' + dName + '" loading="lazy" onerror="this.src=\'' + getErrorImg(dName) + '\'">';
        html += '<div class="ps-list-info"><div class="ps-list-name">' + dName + '</div>';
        html += '<div class="ps-list-sub">' + cat + ' • Free</div></div>';
        html += '<button class="ps-install-btn" onclick="event.stopPropagation();location.href=\'app.html?id=' + app.id + '\'">Install</button></div>';
    });
    return html;
}

function showAllApps() {
    var sec = document.getElementById('allAppsSection');
    if (sec) { sec.style.display='block'; sec.scrollIntoView({behavior:'smooth'}); }
}
function hideAllApps() {
    var sec = document.getElementById('allAppsSection');
    if (sec) sec.style.display = 'none';
}
function filterByCat(cat) {
    var main = document.getElementById('mainContent');
    var apps = sortByDate(allApps.filter(function(a){ return a.category === cat; }));
    var catName = cat.charAt(0).toUpperCase() + cat.slice(1);
    var html = '<div style="padding:12px 16px;display:flex;align-items:center;gap:10px;">';
    html += '<button onclick="renderHome()" style="background:none;border:none;font-size:18px;cursor:pointer;color:#1a73e8;"><i class="fas fa-arrow-left"></i></button>';
    html += '<span style="font-size:15px;font-weight:600;color:#333;">' + catName + ' (' + apps.length + ')</span></div>';
    html += buildAllList(apps);
    main.innerHTML = html;
}

// ========== INIT ==========
(function init() {

    var cachedHomeHTML   = cacheGet('homeHTML');
    var cachedBannerHTML = cacheGet('bannerHTML');
    var cachedApps       = cacheGet('apps');
    var cachedBanners    = cacheGet('banners');

    // ===== Banner: cached HTML সাথে সাথে দেখাও =====
    if (cachedBannerHTML) {
        var section = document.getElementById('bannerSection');
        if (section) {
            section.innerHTML = cachedBannerHTML;
            bannersRendered = true;
            if (cachedBanners) {
                allBanners = Object.keys(cachedBanners).map(function(k){
                    return Object.assign({id:k}, cachedBanners[k]);
                });
                if (allBanners.length > 1) {
                    setTimeout(function() {
                        bannerInterval = setInterval(function() {
                            currentBannerIndex = (currentBannerIndex + 1) % allBanners.length;
                            slideBanner();
                        }, 4000);
                    }, 300);
                }
            }
        }
    }

    // ===== Apps: cached HTML সাথে সাথে দেখাও — loading নেই =====
    if (cachedApps) {
        allApps = Object.keys(cachedApps).map(function(k){
            return processAppName(Object.assign({id:k}, cachedApps[k]));
        });
    }

    if (cachedHomeHTML) {
        // ✅ cached HTML → loading spinner দেখাবেই না
        var main = document.getElementById('mainContent');
        if (main) main.innerHTML = cachedHomeHTML;
    } else if (cachedApps && allApps.length > 0) {
        // cache আছে কিন্তু homeHTML নেই → render করো
        renderHome();
    } else {
        // একদম প্রথমবার → শুধু তখনই spinner
        var main = document.getElementById('mainContent');
        if (main) main.innerHTML = '<div class="loading-screen"><div class="spinner"></div><p>Loading apps...</p></div>';
        var bs = document.getElementById('bannerSection');
        if (bs) bs.innerHTML = '<div class="loading-screen"><div class="spinner"></div><p>Loading...</p></div>';
    }

    // ===== Firebase Realtime — silently update =====
    fbAppsRef = db.ref('apps');
    fbAppsRef.on('value', function(snap) {
        var data = snap.val();
        if (!data) return;
        var newApps = Object.keys(data).map(function(k){
            return processAppName(Object.assign({id:k}, data[k]));
        });
        cacheSet('apps', data);
        var oldIds = allApps.map(function(a){return a.id;}).sort().join();
        var newIds = newApps.map(function(a){return a.id;}).sort().join();
        if (oldIds !== newIds) {
            allApps = newApps;
            renderHome(); // নতুন app আসলে silently update
        } else {
            allApps = newApps;
        }
    });

    fbBannersRef = db.ref('banners');
    fbBannersRef.on('value', function(snap) {
        var data = snap.val();
        if (!data) return;
        var newBanners = Object.keys(data).map(function(k){
            return Object.assign({id:k}, data[k]);
        });
        cacheSet('banners', data);
        if (!bannersRendered || newBanners.length !== allBanners.length) {
            allBanners = newBanners;
            renderBanners();
            bannersRendered = true;
        }
    });

    // ===== BFCache: pagehide-এ Firebase disconnect =====
    window.addEventListener('pagehide', function() {
        if (bannerInterval) { clearInterval(bannerInterval); bannerInterval = null; }
        if (fbAppsRef)    fbAppsRef.off();
        if (fbBannersRef) fbBannersRef.off();
    });

    // ===== BFCache: pageshow-এ reconnect =====
    window.addEventListener('pageshow', function(e) {
        if (e.persisted) {
            // BFCache থেকে restore — reload হয়নি ✅
            fbAppsRef = db.ref('apps');
            fbAppsRef.on('value', function(snap) {
                var data = snap.val(); if (!data) return;
                var newApps = Object.keys(data).map(function(k){
                    return processAppName(Object.assign({id:k}, data[k]));
                });
                cacheSet('apps', data);
                var oldIds = allApps.map(function(a){return a.id;}).sort().join();
                var newIds = newApps.map(function(a){return a.id;}).sort().join();
                if (oldIds !== newIds) { allApps = newApps; renderHome(); }
                else { allApps = newApps; }
            });
            fbBannersRef = db.ref('banners');
            fbBannersRef.on('value', function(snap) {
                var data = snap.val(); if (!data) return;
                cacheSet('banners', data);
            });
            if (allBanners.length > 1 && !bannerInterval) {
                bannerInterval = setInterval(function() {
                    currentBannerIndex = (currentBannerIndex + 1) % allBanners.length;
                    slideBanner();
                }, 4000);
            }
        }
    });

})();
